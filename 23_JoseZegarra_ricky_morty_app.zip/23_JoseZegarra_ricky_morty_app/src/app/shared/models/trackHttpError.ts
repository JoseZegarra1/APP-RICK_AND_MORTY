export class TrackHttpError{
  errorNumber:number;
  message: string;
  friendlyMessage: string;
}
